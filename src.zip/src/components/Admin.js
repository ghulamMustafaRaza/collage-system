import React from 'react'

class Admin extends React.Component{
    render(){
        return(
            <div>
                <h1 className="text-center">Admin</h1>
            </div>
        )
    }
}
export default Admin