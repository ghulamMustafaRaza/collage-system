import React,{Component as C} from 'react'
import * as firebase from "firebase"
import userImg from "../img/user.png"

export default class UserPanel extends C{
    constructor(props){
        super(props)
        this.state={
            user:null,
            dataBase: null
        }
    }
    componentDidMount(){
        firebase.auth().onAuthStateChanged(()=>{
            var uid = firebase.auth().currentUser.uid;
            var dataBase;
            firebase.database().ref('student').once('value',(snapshot)=>{
                alert('a')
                if (snapshot.hasChild(uid)) {
                    alert('b')                    
                    let value =firebase.database().ref("student").child(uid);
                    alert(value)
                    value.once("value", (snap)=>{
                        dataBase = snap.val()
                        this.setState({
                            dataBase
                        })
                    })
                    alert(value)
                    // dataBase = firebase.database().ref("student/"+firebase.auth().currentUser.uid).val()
                }else{
                    alert('c')                    
                    let value =firebase.database().ref("company").child(firebase.auth().currentUser.uid)
                    // alert(value)
                    value.once("value", (snap)=>{
                        dataBase = snap.val()
                    })
                    // dataBase = firebase.database().ref("company").child(firebase.auth().currentUser.uid).val()
                }
            });
            console.log()
            // var dataBase = (  firebase.database().ref("company/",firebase.auth().currentUser.uid).child("type").val || 'admin') 
            console.log("dtatabasa:"+dataBase)
            this.setState({
                user: firebase.auth().currentUser,
                dataBase
            })
        })
    }
    
    render(){
        return(
            <div className="userpanel">
                <h1 className="text-center">User Type : {this.state.dataBase&&this.state.dataBase.type}
                </h1>
                <img src={(this.state.user&&this.state.user.photoURL||userImg)} alt="" className="img"/>
            </div>
        )
    }
}
