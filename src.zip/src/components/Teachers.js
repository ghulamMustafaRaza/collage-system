import React from 'react'

class Teachers extends React.Component{
    render(){
        return(
            <div>
                <h1 className="text-center">Teachers</h1>
            </div>
        )
    }
}
export default Teachers